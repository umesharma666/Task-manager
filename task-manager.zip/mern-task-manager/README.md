# MERN Task Manager (Auth + CRUD)

A beginner-friendly MERN stack project featuring JWT authentication and task CRUD.

## Features
- User registration and login (JWT)
- Create, read, update, delete tasks
- Mark tasks complete/incomplete
- Protected REST APIs
- Clean, minimal React UI

## Tech
MongoDB, Express.js, React (Vite), Node.js, JWT, Mongoose

---

## Quick Start

### 1) Prerequisites
- Node.js 18+
- MongoDB running locally or a MongoDB Atlas URI

### 2) Backend
```bash
cd server
cp .env.example .env   # fill in MONGO_URI and JWT_SECRET
npm install
npm run dev            # starts on http://localhost:5000
```

### 3) Frontend
```bash
cd client
cp .env.example .env   # (optional) to override API URL
npm install
npm run dev            # Vite dev server (shown in terminal), usually http://localhost:5173
```

Default API base URL in the frontend is `http://localhost:5000`. You can change it via `client/.env`:

```
VITE_API_URL=http://localhost:5000
```

### 4) Build for Production
```bash
# Build React
cd client
npm run build

# (Optional) Serve the built files with any static host.
```

### 5) Suggested GitHub Steps
```bash
git init
git add .
git commit -m "MERN Task Manager: auth + CRUD"
git branch -M main
git remote add origin <YOUR_REPO_URL>
git push -u origin main
```

### 6) Resume Bullets (paste as-is)
- Built a MERN-based Task Manager with JWT auth, implementing secure REST APIs for user registration/login and task CRUD.
- Designed Mongoose schemas and Express middleware for role-free, token-protected routes; enabled CORS and environment-based config.
- Built a clean React (Vite) frontend with protected views, token storage, and optimistic UI for task create/update/delete.

---

## API Overview

**Auth**
- `POST /api/auth/register` → body: `{ name, email, password }`
- `POST /api/auth/login` → body: `{ email, password }` → returns `{ token }`

**Tasks** _(requires Authorization: Bearer <token>)_
- `GET /api/tasks`
- `POST /api/tasks` → body: `{ title, description }`
- `PUT /api/tasks/:id` → body: `{ title?, description?, completed? }`
- `DELETE /api/tasks/:id`

---

## License
MIT
