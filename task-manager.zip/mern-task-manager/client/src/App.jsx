import React, { useEffect, useState } from 'react'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import Dashboard from './pages/Dashboard.jsx'

export default function App() {
  const [view, setView] = useState('login')
  const [user, setUser] = useState(() => {
    const u = localStorage.getItem('user')
    return u ? JSON.parse(u) : null
  })

  useEffect(() => {
    if (user) setView('dashboard')
  }, [user])

  function handleLogout() {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    setUser(null)
    setView('login')
  }

  return (
    <div className="container">
      {view === 'login' && <Login onSwitch={() => setView('register')} onLoggedIn={setUser} />}
      {view === 'register' && <Register onSwitch={() => setView('login')} />}
      {view === 'dashboard' && <Dashboard user={user} onLogout={handleLogout} />}
    </div>
  )
}
