import React, { useState } from 'react'

export default function TaskForm({ onCreate }) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')

  async function submit(e) {
    e.preventDefault()
    if (!title.trim()) return
    await onCreate({ title: title.trim(), description: description.trim() })
    setTitle(''); setDescription('')
  }

  return (
    <form onSubmit={submit} className="grid">
      <h3>Add Task</h3>
      <input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
      <textarea placeholder="Description (optional)" rows="3" value={description} onChange={e => setDescription(e.target.value)} />
      <button className="btn">Add Task</button>
    </form>
  )
}
