import React, { useState } from 'react'

export default function TaskItem({ task, onToggle, onEdit, onDelete }) {
  const [editing, setEditing] = useState(false)
  const [title, setTitle] = useState(task.title)
  const [description, setDescription] = useState(task.description || '')

  async function save() {
    await onEdit({ title, description })
    setEditing(false)
  }

  return (
    <div className="task">
      <div style={{ flex: 1, marginRight: 10 }}>
        {!editing ? (
          <>
            <div className="title">{task.completed ? <s>{task.title}</s> : task.title}</div>
            {task.description && <div className="desc">{task.description}</div>}
            <small className="muted">{new Date(task.createdAt).toLocaleString()}</small>
          </>
        ) : (
          <div className="grid">
            <input value={title} onChange={e => setTitle(e.target.value)} />
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows="3" />
          </div>
        )}
      </div>
      <div className="actions">
        <button className="btn secondary" onClick={onToggle}>{task.completed ? 'Undo' : 'Done'}</button>
        {!editing ? (
          <button className="btn" onClick={() => setEditing(true)}>Edit</button>
        ) : (
          <button className="btn" onClick={save}>Save</button>
        )}
        <button className="btn secondary" onClick={onDelete}>Delete</button>
      </div>
    </div>
  )
}
