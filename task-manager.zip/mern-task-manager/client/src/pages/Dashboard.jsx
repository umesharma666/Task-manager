import React, { useEffect, useState } from 'react'
import { getTasks, createTask, updateTask, deleteTask } from '../api'
import TaskForm from '../components/TaskForm.jsx'
import TaskItem from '../components/TaskItem.jsx'

export default function Dashboard({ user, onLogout }) {
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    (async () => {
      try {
        const data = await getTasks()
        setTasks(data)
      } catch (e) { setError('Failed to load tasks') }
      finally { setLoading(false) }
    })()
  }, [])

  async function handleCreate({ title, description }) {
    const newTask = await createTask({ title, description })
    setTasks([newTask, ...tasks])
  }
  async function handleToggle(task) {
    const updated = await updateTask(task._id, { completed: !task.completed })
    setTasks(tasks.map(t => t._id === task._id ? updated : t))
  }
  async function handleEdit(task, updates) {
    const updated = await updateTask(task._id, updates)
    setTasks(tasks.map(t => t._id === task._id ? updated : t))
  }
  async function handleDelete(task) {
    await deleteTask(task._id)
    setTasks(tasks.filter(t => t._id !== task._id))
  }

  return (
    <div className="grid" style={{ gap: 16 }}>
      <div className="nav">
        <div>
          <h2>Hi, {user?.name}</h2>
          <small className="muted">{user?.email}</small>
        </div>
        <button className="btn secondary" onClick={onLogout}>Logout</button>
      </div>

      <div className="card">
        <TaskForm onCreate={handleCreate} />
      </div>

      <div className="card grid" style={{ gap: 12 }}>
        <h3>Your Tasks</h3>
        {loading && <small className="muted">Loading...</small>}
        {error && <small style={{ color: 'crimson' }}>{error}</small>}
        {!loading && tasks.length === 0 && <small className="muted">No tasks yet. Add one above.</small>}
        <div className="grid" style={{ gap: 10 }}>
          {tasks.map(task => (
            <TaskItem key={task._id} task={task} onToggle={() => handleToggle(task)} onEdit={(updates) => handleEdit(task, updates)} onDelete={() => handleDelete(task)} />
          ))}
        </div>
      </div>
    </div>
  )
}
