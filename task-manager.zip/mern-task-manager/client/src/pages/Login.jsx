import React, { useState } from 'react'
import { apiLogin } from '../api'

export default function Login({ onSwitch, onLoggedIn }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setLoading(true); setError('')
    try {
      const { token, user } = await apiLogin(email, password)
      localStorage.setItem('token', token)
      localStorage.setItem('user', JSON.stringify(user))
      onLoggedIn(user)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="card grid" style={{ maxWidth: 420, margin: '80px auto' }}>
      <h1>Task Manager</h1>
      <p><small className="muted">Login to manage your tasks</small></p>
      <form onSubmit={handleSubmit} className="grid">
        <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
        <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
        {error && <small style={{ color: 'crimson' }}>{error}</small>}
        <button className="btn" disabled={loading}>{loading ? 'Logging in...' : 'Login'}</button>
      </form>
      <small>New here? <a className="link" onClick={onSwitch}>Create an account</a></small>
    </div>
  )
}
