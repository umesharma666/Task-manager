import React, { useState } from 'react'
import { apiRegister } from '../api'

export default function Register({ onSwitch }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setLoading(true); setError(''); setMessage('')
    try {
      await apiRegister(name, email, password)
      setMessage('Account created! You can login now.')
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="card grid" style={{ maxWidth: 480, margin: '80px auto' }}>
      <h1>Create Account</h1>
      <form onSubmit={handleSubmit} className="grid">
        <input placeholder="Full name" value={name} onChange={e => setName(e.target.value)} />
        <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
        <input type="password" placeholder="Password (min 6)" value={password} onChange={e => setPassword(e.target.value)} />
        {error && <small style={{ color: 'crimson' }}>{error}</small>}
        {message && <small className="badge">{message}</small>}
        <button className="btn" disabled={loading}>{loading ? 'Creating...' : 'Register'}</button>
      </form>
      <small>Already have an account? <a className="link" onClick={onSwitch}>Login</a></small>
    </div>
  )
}
